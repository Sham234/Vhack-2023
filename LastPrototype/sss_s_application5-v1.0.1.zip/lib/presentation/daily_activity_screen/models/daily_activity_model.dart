class DailyActivityModel {}
