class AvatarClothesOneModel {}
