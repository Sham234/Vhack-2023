class AvatarModel {}
