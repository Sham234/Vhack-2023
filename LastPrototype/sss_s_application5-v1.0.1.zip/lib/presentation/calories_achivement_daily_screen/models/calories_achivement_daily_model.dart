class CaloriesAchivementDailyModel {}
