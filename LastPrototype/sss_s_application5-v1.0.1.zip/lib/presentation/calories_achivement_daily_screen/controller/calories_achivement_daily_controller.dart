import 'package:sss_s_application5/core/app_export.dart';
import 'package:sss_s_application5/presentation/calories_achivement_daily_screen/models/calories_achivement_daily_model.dart';

class CaloriesAchivementDailyController extends GetxController {
  Rx<CaloriesAchivementDailyModel> caloriesAchivementDailyModelObj =
      CaloriesAchivementDailyModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
