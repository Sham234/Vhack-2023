import 'package:sss_s_application5/core/app_export.dart';
import 'package:sss_s_application5/presentation/checkpoint_screen/models/checkpoint_model.dart';

class CheckpointController extends GetxController {
  Rx<CheckpointModel> checkpointModelObj = CheckpointModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
