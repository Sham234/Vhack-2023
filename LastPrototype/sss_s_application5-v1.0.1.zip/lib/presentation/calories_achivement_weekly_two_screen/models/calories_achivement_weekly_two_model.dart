class CaloriesAchivementWeeklyTwoModel {}
