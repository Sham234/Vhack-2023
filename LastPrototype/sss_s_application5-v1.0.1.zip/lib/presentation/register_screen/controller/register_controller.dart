import 'package:sss_s_application5/core/app_export.dart';
import 'package:sss_s_application5/presentation/register_screen/models/register_model.dart';

class RegisterController extends GetxController {
  Rx<RegisterModel> registerModelObj = RegisterModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
