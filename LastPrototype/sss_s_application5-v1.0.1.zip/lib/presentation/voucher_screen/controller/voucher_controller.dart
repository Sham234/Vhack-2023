import 'package:sss_s_application5/core/app_export.dart';
import 'package:sss_s_application5/presentation/voucher_screen/models/voucher_model.dart';

class VoucherController extends GetxController {
  Rx<VoucherModel> voucherModelObj = VoucherModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
