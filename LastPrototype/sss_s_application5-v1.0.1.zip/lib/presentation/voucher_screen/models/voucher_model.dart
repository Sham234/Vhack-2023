class VoucherModel {}
