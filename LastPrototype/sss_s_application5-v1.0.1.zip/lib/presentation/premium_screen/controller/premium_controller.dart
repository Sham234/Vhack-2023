import 'package:sss_s_application5/core/app_export.dart';
import 'package:sss_s_application5/presentation/premium_screen/models/premium_model.dart';

class PremiumController extends GetxController {
  Rx<PremiumModel> premiumModelObj = PremiumModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
