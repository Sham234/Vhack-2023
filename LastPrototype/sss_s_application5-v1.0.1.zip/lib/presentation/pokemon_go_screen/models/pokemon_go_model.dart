class PokemonGoModel {}
