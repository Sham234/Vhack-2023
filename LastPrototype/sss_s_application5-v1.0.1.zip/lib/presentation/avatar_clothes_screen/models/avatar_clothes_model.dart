class AvatarClothesModel {}
