class AddFriendModel {}
