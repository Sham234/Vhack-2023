class PokemonLocationModel {}
