import 'package:get/get.dart';
import 'listlanguage1_item_model.dart';

class CaloriesAchivementWeeklyModel {
  RxList<Listlanguage1ItemModel> listlanguage1ItemList =
      RxList.generate(2, (index) => Listlanguage1ItemModel());
}
