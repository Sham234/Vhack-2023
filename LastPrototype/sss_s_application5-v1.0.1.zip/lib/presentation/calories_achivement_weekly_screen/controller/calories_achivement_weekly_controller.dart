import 'package:sss_s_application5/core/app_export.dart';
import 'package:sss_s_application5/presentation/calories_achivement_weekly_screen/models/calories_achivement_weekly_model.dart';

class CaloriesAchivementWeeklyController extends GetxController {
  Rx<CaloriesAchivementWeeklyModel> caloriesAchivementWeeklyModelObj =
      CaloriesAchivementWeeklyModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
