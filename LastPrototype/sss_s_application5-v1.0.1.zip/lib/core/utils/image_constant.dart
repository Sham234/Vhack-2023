class ImageConstant {
  static String imgAvatar181121x371 = 'assets/images/img_avatar181_121x371.png';

  static String img1notification = 'assets/images/img_1notification.png';

  static String imgAvatar61 = 'assets/images/img_avatar61.png';

  static String imgArrowdownBlack900 =
      'assets/images/img_arrowdown_black_900.svg';

  static String img401 = 'assets/images/img_401.png';

  static String imgAvatar141 = 'assets/images/img_avatar141.png';

  static String imgAvatar471 = 'assets/images/img_avatar471.png';

  static String imgAvatar41 = 'assets/images/img_avatar41.png';

  static String img1281 = 'assets/images/img_1281.png';

  static String imgAvatar41104x142 = 'assets/images/img_avatar41_104x142.png';

  static String img331 = 'assets/images/img_331.png';

  static String imgImage12 = 'assets/images/img_image12.png';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String img1822 = 'assets/images/img_1822.png';

  static String img222 = 'assets/images/img_222.png';

  static String imgImage6 = 'assets/images/img_image6.png';

  static String imgImage22 = 'assets/images/img_image22.png';

  static String imgImage2 = 'assets/images/img_image2.png';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgAvatar451 = 'assets/images/img_avatar451.png';

  static String img223 = 'assets/images/img_223.png';

  static String img151 = 'assets/images/img_151.png';

  static String imgAvatar361 = 'assets/images/img_avatar361.png';

  static String imgAvatar182 = 'assets/images/img_avatar182.png';

  static String imgUserBlueGray70001 =
      'assets/images/img_user_blue_gray_700_01.svg';

  static String imgAvatar481 = 'assets/images/img_avatar481.png';

  static String imgRectangle177 = 'assets/images/img_rectangle177.png';

  static String imgLock = 'assets/images/img_lock.svg';

  static String img321 = 'assets/images/img_321.png';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgComponent7 = 'assets/images/img_component7.svg';

  static String img411 = 'assets/images/img_411.png';

  static String imgShare = 'assets/images/img_share.svg';

  static String imgAvatar431 = 'assets/images/img_avatar431.png';

  static String imgAvatar161 = 'assets/images/img_avatar161.png';

  static String imgGroup928 = 'assets/images/img_group928.svg';

  static String imgAvatar183 = 'assets/images/img_avatar183.png';

  static String imgImage13 = 'assets/images/img_image13.png';

  static String imgImage10 = 'assets/images/img_image10.png';

  static String imgReply = 'assets/images/img_reply.svg';

  static String imgAvatar82 = 'assets/images/img_avatar82.png';

  static String imgArrowleftOrange30001 =
      'assets/images/img_arrowleft_orange_300_01.svg';

  static String imgNumber2iconr = 'assets/images/img_number2iconr.png';

  static String imgImage24 = 'assets/images/img_image24.png';

  static String imgNumber3removebgpreview =
      'assets/images/img_number3removebgpreview.png';

  static String imgArrowdownDeepOrange300 =
      'assets/images/img_arrowdown_deep_orange_300.svg';

  static String img1301 = 'assets/images/img_1301.png';

  static String imgAvatar482 = 'assets/images/img_avatar482.png';

  static String imgAvatar155 = 'assets/images/img_avatar155.png';

  static String imgRectangle96 = 'assets/images/img_rectangle96.png';

  static String img1821 = 'assets/images/img_1821.png';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String img281 = 'assets/images/img_281.png';

  static String imgMaterialsymbol = 'assets/images/img_materialsymbol.svg';

  static String imgAvatar151 = 'assets/images/img_avatar151.png';

  static String img431 = 'assets/images/img_431.png';

  static String imgArrowrightOrange30004 =
      'assets/images/img_arrowright_orange_300_04.svg';

  static String img111 = 'assets/images/img_111.png';

  static String img341 = 'assets/images/img_341.png';

  static String imgAvatar121 = 'assets/images/img_avatar121.png';

  static String imgRectangle98 = 'assets/images/img_rectangle98.png';

  static String imgImage14 = 'assets/images/img_image14.png';

  static String img45688 = 'assets/images/img_45688.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String img1246 = 'assets/images/img_1246.png';

  static String img551 = 'assets/images/img_551.png';

  static String imgRectangle101 = 'assets/images/img_rectangle101.png';

  static String img1211 = 'assets/images/img_1211.png';

  static String imgImage32 = 'assets/images/img_image32.png';

  static String imgImage18 = 'assets/images/img_image18.png';

  static String imgArrowdownDeepOrange30003 =
      'assets/images/img_arrowdown_deep_orange_300_03.svg';

  static String img311 = 'assets/images/img_311.png';

  static String imgSportbackground = 'assets/images/img_sportbackground.png';

  static String imgReplyWhiteA700 = 'assets/images/img_reply_white_a700.svg';

  static String img1221 = 'assets/images/img_1221.png';

  static String img1231 = 'assets/images/img_1231.png';

  static String imgTng1 = 'assets/images/img_tng1.png';

  static String img821 = 'assets/images/img_821.png';

  static String imgImage29 = 'assets/images/img_image29.png';

  static String img371 = 'assets/images/img_371.png';

  static String img221 = 'assets/images/img_221.png';

  static String imgUserCyan200 = 'assets/images/img_user_cyan_200.svg';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgAvatar381 = 'assets/images/img_avatar381.png';

  static String img561 = 'assets/images/img_561.png';

  static String imgFire = 'assets/images/img_fire.svg';

  static String img421 = 'assets/images/img_421.png';

  static String imgFirePink600 = 'assets/images/img_fire_pink_600.svg';

  static String imgArrowrightDeepOrange300 =
      'assets/images/img_arrowright_deep_orange_300.svg';

  static String imgLogoremovedwhite = 'assets/images/img_logoremovedwhite.png';

  static String imgReplyDeepOrange300 =
      'assets/images/img_reply_deep_orange_300.svg';

  static String imgAvatar158 = 'assets/images/img_avatar158.png';

  static String imgPolygon9 = 'assets/images/img_polygon9.svg';

  static String imgArrowrightAmber300 =
      'assets/images/img_arrowright_amber_300.svg';

  static String imgAvatar411 = 'assets/images/img_avatar411.png';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgAvatar441 = 'assets/images/img_avatar441.png';

  static String imgAvatar81 = 'assets/images/img_avatar81.png';

  static String imgFireRed500 = 'assets/images/img_fire_red_500.svg';

  static String img811 = 'assets/images/img_811.png';

  static String imgGroup923 = 'assets/images/img_group923.svg';

  static String imgGroup755 = 'assets/images/img_group755.svg';

  static String img71 = 'assets/images/img_71.png';

  static String img491 = 'assets/images/img_491.png';

  static String imgAvatar1028 = 'assets/images/img_avatar1028.png';

  static String imgAvatar181 = 'assets/images/img_avatar181.png';

  static String imgImage11 = 'assets/images/img_image11.png';

  static String imgGroup926 = 'assets/images/img_group926.svg';

  static String imgImage7 = 'assets/images/img_image7.png';

  static String imgImage25 = 'assets/images/img_image25.png';

  static String imgImage20 = 'assets/images/img_image20.png';

  static String img231 = 'assets/images/img_231.png';

  static String img211 = 'assets/images/img_211.png';

  static String imgArrowdownWhiteA700 =
      'assets/images/img_arrowdown_white_a700.svg';

  static String imgCheckpoint = 'assets/images/img_checkpoint.png';

  static String img501 = 'assets/images/img_501.png';

  static String imgPlus = 'assets/images/img_plus.svg';

  static String imgAvatar71 = 'assets/images/img_avatar71.png';

  static String imgImage17 = 'assets/images/img_image17.png';

  static String img2024 = 'assets/images/img_2024.png';

  static String imgImage1 = 'assets/images/img_image1.png';

  static String imgGroup929 = 'assets/images/img_group929.svg';

  static String imgBackremovebgpreview =
      'assets/images/img_backremovebgpreview.png';

  static String imgMdicrown = 'assets/images/img_mdicrown.svg';

  static String imgAvatar501 = 'assets/images/img_avatar501.png';

  static String img121 = 'assets/images/img_121.png';

  static String imgLocationBlueGray70001 =
      'assets/images/img_location_blue_gray_700_01.svg';

  static String imgEdit = 'assets/images/img_edit.svg';

  static String imgImage3 = 'assets/images/img_image3.png';

  static String imgRectangle137 = 'assets/images/img_rectangle137.svg';

  static String imgAvatar461 = 'assets/images/img_avatar461.png';

  static String imgLocation = 'assets/images/img_location.svg';

  static String img381 = 'assets/images/img_381.png';

  static String img61 = 'assets/images/img_61.png';

  static String imgImage35 = 'assets/images/img_image35.png';

  static String imgRectangle165 = 'assets/images/img_rectangle165.svg';

  static String imgFavorite = 'assets/images/img_favorite.svg';

  static String imgAvatar421 = 'assets/images/img_avatar421.png';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgFavoriteBlack900 =
      'assets/images/img_favorite_black_900.svg';

  static String imgFireDeepOrange300 =
      'assets/images/img_fire_deep_orange_300.svg';

  static String imgAvatar191 = 'assets/images/img_avatar191.png';

  static String imgPolygon8 = 'assets/images/img_polygon8.svg';

  static String imgGroup924 = 'assets/images/img_group924.svg';

  static String imgGroup927 = 'assets/images/img_group927.svg';

  static String img1291 = 'assets/images/img_1291.png';

  static String imgChatbox = 'assets/images/img_chatbox.png';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgReplyAmber300 = 'assets/images/img_reply_amber_300.svg';

  static String imgAvatar71340x375 = 'assets/images/img_avatar71_340x375.png';

  static String img301 = 'assets/images/img_301.png';

  static String imgNumber1iconr = 'assets/images/img_number1iconr.png';

  static String imgComponent7Amber10001 =
      'assets/images/img_component7_amber_100_01.svg';

  static String imgAvatar156 = 'assets/images/img_avatar156.png';

  static String imgImage16 = 'assets/images/img_image16.png';

  static String imgEye = 'assets/images/img_eye.svg';

  static String imgAvatar201 = 'assets/images/img_avatar201.png';

  static String imgAvatar51 = 'assets/images/img_avatar51.png';

  static String imgAvatar491 = 'assets/images/img_avatar491.png';

  static String imgRectangle276 = 'assets/images/img_rectangle276.png';

  static String imgComputer = 'assets/images/img_computer.svg';

  static String imgAvatar101 = 'assets/images/img_avatar101.png';

  static String img141 = 'assets/images/img_141.png';

  static String imgImage36 = 'assets/images/img_image36.png';

  static String imgAvatar111 = 'assets/images/img_avatar111.png';

  static String img131 = 'assets/images/img_131.png';

  static String imgAvatar131 = 'assets/images/img_avatar131.png';

  static String imgMinimize = 'assets/images/img_minimize.svg';

  static String img361 = 'assets/images/img_361.png';

  static String imgUserBlack900 = 'assets/images/img_user_black_900.svg';

  static String imgShareOrange30003 =
      'assets/images/img_share_orange_300_03.svg';

  static String imgArrowleftWhiteA700 =
      'assets/images/img_arrowleft_white_a700.svg';

  static String img358 = 'assets/images/img_358.png';

  static String imgImage4 = 'assets/images/img_image4.png';

  static String img1201 = 'assets/images/img_1201.png';

  static String imgImage19 = 'assets/images/img_image19.png';

  static String imgArrowleftGreen200 =
      'assets/images/img_arrowleft_green_200.svg';

  static String imgSportbackground812x375 =
      'assets/images/img_sportbackground_812x375.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
